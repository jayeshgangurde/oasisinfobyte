while True:
    a = input()
    if a == "hii":
        print("hii")
    elif a =="how are you?":
        print("i am fine")
    elif a =="what are doing here?":
        print("i can help to you")
    elif a =="what is your name":
        print("i am bot")
    elif a =="bye":
        print("bye...visit again")
        break
